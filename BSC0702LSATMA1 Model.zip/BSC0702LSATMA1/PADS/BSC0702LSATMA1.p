*PADS-LIBRARY-PART-TYPES-V9*

BSC0702LSATMA1 BSC0702LSATMA1 I TRX 9 1 0 0 0
TIMESTAMP 2026.05.23.20.10.47
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" BSC0702LSATMA1
"Mouser Part Number" 726-BSC0702LSATMA1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/BSC0702LSATMA1?qs=u4fy%2FsgLU9NYVEIY04ctJg%3D%3D
"Arrow Part Number" BSC0702LSATMA1
"Arrow Price/Stock" https://www.arrow.com/en/products/bsc0702lsatma1/infineon-technologies-ag?region=europe
"Description" N-Channel 60 V 100A (Tc) 83W (Tc) Surface Mount PG-TDSON-8,2.7 mOhms,- 20 V, + 20 V.
"Datasheet Link" https://www.infineon.com/dgdl/Infineon-BSC0702LS-DataSheet-v02_03-EN.pdf?fileId=5546d4626fc1ce0b016ff0909c6f4eda
"Geometry.Height" 1.2mm
GATE 1 9 0
BSC0702LSATMA1
1 0 U SOURCE_1
2 0 U SOURCE_2
3 0 U SOURCE_3
4 0 U GATE
5 0 U DRAIN_1
6 0 U DRAIN_2
7 0 U DRAIN_3
8 0 U DRAIN_4
9 0 U DRAIN_5

*END*
*REMARK* SamacSys ECAD Model
1651242/1818820/2.50/9/3/MOSFET (N-Channel)
